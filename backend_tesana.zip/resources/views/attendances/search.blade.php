@extends('template.app')

@section('title', 'Mis asistencias')

@section('content')
<nav class="mb-2">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="{{ route('index_client') }}">Inicio</a></li>
    <li class="breadcrumb-item active">Mis asistencias</li>
  </ol>
</nav>

<div class="card">
	<div class="table-responsive">
		<table class="table card-table table-vcenter">
			<thead>
				<tr>
					<th>Alumno</th>
					<th>Fecha</th>
				</tr>
			</thead>
			<tbody>
				@if($attendances->count() > 0)
				@foreach($attendances as $attendance)
				<tr>
					<td>{{ optional($attendance->client)->name }}</td>
					<td>{{ $attendance->date->format('d/m/Y H:i') }}</td>	
				</tr>
				@endforeach
				@else
				<tr>
					<td colspan="2" align="center">No se han encontrado registrado</td>
				</tr>
				@endif
			</tbody>
		</table>
	</div>

	@if($attendances->hasPages())
	<div class="card-footer d-flex align-items-center">
		{{ $attendances->withQueryString()->links() }}
	</div>
	@endif
</div>
@endsection
