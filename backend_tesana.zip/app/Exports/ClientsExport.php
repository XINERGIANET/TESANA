<?php

namespace App\Exports;

use Illuminate\Http\Request;
use App\Models\ClientService;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;


class ClientsExport implements FromCollection, WithHeadings, WithMapping, WithStyles, ShouldAutoSize
{


    public function collection()
    {
        $request = request();
        return ClientService::active()->when($request->document, function($query, $document){
            return $query->whereHas('client', function($query) use ($document){
                return $query->where('document', $document);
            });
        })->when($request->name, function($query, $name){
            return $query->whereHas('client', function($query) use ($name){
                return $query->where('name', 'like', '%'.$name.'%');
            });
        })->when($request->year, function($query, $year){
            return $query->whereYear('start_date', $year);
        })->when($request->month, function($query, $month){
            return $query->whereMonth('start_date', $month);
        })->when($request->sessions, function($query, $sessions){
            return $query->whereHas('service', function($query) use ($sessions){
                return $query->where('sessions', $sessions);
            });
        })->oldest('end_date')->get();
    }

    public function map($client_service): array
    {
        return [
            optional($client_service->client)->document,
            optional($client_service->client)->name,
            optional($client_service->service)->name,
            number_format($client_service->total, 2),
            optional($client_service->start_date)->format('d/m/Y'),
            optional($client_service->end_date)->format('d/m/Y'),
            optional($client_service->payment_date)->format('d/m/Y'),
            optional($client_service->client)->profile(),
            strtotime($client_service->end_date) >= strtotime(date('Y-m-d')) ? 'Si' : 'No'
        ];
    }

    public function headings(): array
    {
        return [
            'DNI',
            'Nombre',
            'Servicio',
            'Total',
            'Fecha inicial',
            'Fecha final',
            'Fecha pago',
            'Perfil',
            'Activo',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true]]
        ];
    }
}
